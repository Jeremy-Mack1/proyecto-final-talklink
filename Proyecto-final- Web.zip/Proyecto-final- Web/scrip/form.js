document.addEventListener('DOMContentLoaded', function () {

    document.getElementById('save-button').addEventListener('click', function (e) {
        e.preventDefault();



        alert('Datos guardados: Se le envio a su correo la informacion');

    
        const email = document.getElementById('email').value;
        sendEmail(email);
    });


    document.getElementById('back-link').addEventListener('click', function (e) {
        e.preventDefault();
      
    });

    const { google } = require('googleapis');
    const gmail = google.gmail('v1');
    
    async function sendEmail(toEmail) {
      try {
       
        const auth = await authenticateWithGmailAPI();
    
      
        const email = composeEmail(toEmail);
    
        /
        await gmail.users.messages.send({
          userId: 'me',
          resource: {
            raw: email,
          },
          auth,
        });
    
        console.log('Correo electrónico enviado con éxito.');
      } catch (error) {
        console.error('Error al enviar el correo electrónico:', error);
      }
    }
    
    async function authenticateWithGmailAPI() {
 
    }
    
    function composeEmail(toEmail) {
      const subject = 'Pasar por la oficina';
      const message = 'Pase por la oficina';
    
      const emailLines = [
        `To: ${toEmail}`,
        'Content-Type: text/plain; charset="UTF-8"',
        'MIME-Version: 1.0',
        `Subject: ${subject}`,
        '',
        message,
      ];
    
      return Buffer.from(emailLines.join('\r\n')).toString('base64');
    }
    
 
    sendEmail('destinatario@example.com');
    
});
