document.getElementById('login-form').addEventListener('submit', function (e) {
    e.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Aquí puedes realizar la autenticación (por ejemplo, verificar si el usuario y la contraseña son válidos).
    // Esto debería hacerse en el servidor en una aplicación real.

    if (username === 'usuario' && password === 'contraseña') {
        window.location.href = 'dashboard.html'; // Redirigir a la página de inicio después de la autenticación exitosa.
    } else {
        document.getElementById('error-message').textContent = 'Credenciales inválidas. Inténtalo de nuevo.';
    }
});
